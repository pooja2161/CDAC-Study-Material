#include <iostream>
using namespace std;

class Employee
{
  protected:
     // Instance fields , allocated in the instance
     int eid;
	 double sal;
	 double comm;
	 int age;
     static int count; // Shared data member, allocated separately
  						// in data section
  public:
    Employee()
	{
		eid = 1000 + (++count);  //
		sal = 15000;
		comm = 5000;
		age = 21;
	}
    
	Employee(double ss, double cc, int aa)
	{
		eid = 1000 + (++count);  //
        sal = ss;
		comm = cc;
		age = aa;
	}
	void SetSal(double ss) 
	{
		sal = ss;
	}

	double GetSal() const
	{
		return sal;

	}
	void SetComm(double comm)
	{
		this->comm = comm;
	}

	double GetComm() const
	{
		return comm;

	}
	void SetAge(int aa)
	{
		age = aa;
	}

	int GetAge() const
	{
		return age;

	}

	int GetId() const
	{
		return eid;

	}
    void PrintEmployee() const
	{
	   cout << "Employee Id " << eid << endl;
	   cout << "Employee Sal " << sal << endl;
	   cout << "Employee Comm " << comm << endl;
	   cout << "Employee Age " << age << endl;
	}

	virtual double AnnualIncome() const
	{
		double income = 0;
        income = (sal + comm) * 12;
		return income;
	}
};

class SalesPerson : public Employee
{
   private: 
      double sales;

   public:
      SalesPerson() : Employee()
	  {

	  }

      SalesPerson(double ss, double cc, int age, double sa)
	            : Employee(ss, cc, age)
	  {
		  sales = sa;

	  }

      void SetSales(double ss)
	  {
		sales = ss;
	  }

      double GetSales()
	  {
		return sales;
	  }

	  void PrintSalesPerson()
	  {
		 PrintEmployee();
		 cout << "Sales Data " << sales << endl;

	  }

	 double AnnualIncome() const
	 {	
	    double ain = Employee::AnnualIncome();
        ain = ain + 0.25 * sales;
		return ain;
	 }
};


int Employee::count = 0;
//Global Function
double Tax(const Employee* e) 
{
	double income = e->AnnualIncome();
	double tax = (income > 50000) ? (income - 50000) * 0.1 : 0;
    return tax;
}



int main()
{ 
  Employee emp(20000, 2000, 34);
  SalesPerson sp(20000, 2000, 52, 50000);
  emp.PrintEmployee();
  sp.PrintSalesPerson();
  cout << "Annual Income of Employee : " << emp.AnnualIncome() 
       << " and Tax is " << Tax(&emp) <<endl;
  cout << "Annual Income of SalesPerson : " << sp.AnnualIncome()
       << " and Tax is " << Tax(&sp) <<endl;
  return 0;

}




