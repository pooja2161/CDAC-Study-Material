#include <iostream>

using namespace std;
/*
int SumOfAll(int l, int h)
{
	int total = 0;

	for(int count = l; count <= h; count++)
	{
		total = total + count;
	}
    return total;
}

int SumOfEven(int l, int h)
{
	int total = 0;

	for(int count = l; count <= h; count++)
	{
	    if (count % 2 == 0)
			total = total + count;
	}
    return total;
}

int SumOfOdd(int l, int h)
{
	int total = 0;

	for(int count = l; count <= h; count++)
	{
	    if (count % 2 != 0)
			total = total + count;
	}
    return total;
}
*/
/*
float (*seq)(int)
seq is pointer variable
pointing to address of function
Any function which takes one parameter of int
and return float

bool (*check)(int)

int (*add)(int, int)

*/

int SumOfSpecific(int l, int h, bool(*check)(int))
{ 
   int total = 0;
	for(int count = l; count <= h; count++)
	{
	    if (check(count))
			total = total + count;
	}
    return total; 
}

bool isEven(int n)
{
	return (n % 2 == 0);
}

bool isOdd(int n)
{
	return (n % 2 != 0);
}

int check(int n)
{
	return 1;
}

int main()
{
    int num1, num2;
	cout << "Enter Lower Limit" <<  endl;
	cin >> num1;
	cout << "Enter Higher Limit" <<  endl;
	cin >> num2;
	cout << "Sum of Even : " << SumOfSpecific(num1, num2, isEven) << endl;
	cout << "Sum of Odd : " << SumOfSpecific(num1, num2, isOdd) << endl;
	cout << "Sum of Test: " << SumOfSpecific(num1, num2, check) << endl;
    return 0;
}
