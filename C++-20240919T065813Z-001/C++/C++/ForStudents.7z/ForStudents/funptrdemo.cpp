#include <iostream>

using namespace std;

int SumOfAll(int l, int h)
{
	int total = 0;

	for(int count = l; count <= h; count++)
	{
		total = total + count;
	}
    return total;
}

int SumOfEven(int l, int h)
{
	int total = 0;

	for(int count = l; count <= h; count++)
	{
	    if (count % 2 == 0)
			total = total + count;
	}
    return total;
}

int SumOfOdd(int l, int h)
{
	int total = 0;

	for(int count = l; count <= h; count++)
	{
	    if (count % 2 != 0)
			total = total + count;
	}
    return total;
}

int main()
{
    int num1, num2;
	cout << "Enter Lower Limit" <<  endl;
	cin >> num1;
	cout << "Enter Higher Limit" <<  endl;
	cin >> num2;
    int result = SumOfAll(num1, num2);
	cout << "Sum : " << result << endl;
	cout << "Sum of Even : " << SumOfEven(num1, num2) << endl;
	cout << "Sum of Odd : " << SumOfOdd(num1, num2) << endl;
    return 0;
}
