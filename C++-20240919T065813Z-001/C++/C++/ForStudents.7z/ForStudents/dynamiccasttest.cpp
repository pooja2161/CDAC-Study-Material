#include <iostream>
using namespace std;

class Employee
{
  protected:
     // Instance fields , allocated in the instance
     int eid;
	 double sal;
	 double comm;
	 int age;
     static int count; // Shared data member, allocated separately
  						// in data section
  public:
    Employee()
	{
		eid = 1000 + (++count);  //
		sal = 15000;
		comm = 5000;
		age = 21;
	}
    
	Employee(double ss, double cc, int aa)
	{
		eid = 1000 + (++count);  //
        sal = ss;
		comm = cc;
		age = aa;
	}
	void SetSal(double ss) 
	{
		sal = ss;
	}

	double GetSal() const
	{
		return sal;

	}
	void SetComm(double comm)
	{
		this->comm = comm;
	}

	double GetComm() const
	{
		return comm;

	}
	void SetAge(int aa)
	{
		age = aa;
	}

	int GetAge() const
	{
		return age;

	}

	int GetId() const
	{
		return eid;

	}
    void PrintEmployee() const
	{
	   cout << "Employee Id " << eid << endl;
	   cout << "Employee Sal " << sal << endl;
	   cout << "Employee Comm " << comm << endl;
	   cout << "Employee Age " << age << endl;
	}

	virtual double AnnualIncome() const
	{
		double income = 0;
        income = (sal + comm) * 12;
		return income;
	}
};

class SalesPerson : public Employee
{
   private: 
      double sales;

   public:
      SalesPerson() : Employee()
	  {

	  }

      SalesPerson(double ss, double cc, int age, double sa)
	            : Employee(ss, cc, age)
	  {
		  sales = sa;

	  }

      void SetSales(double ss)
	  {
		sales = ss;
	  }

      double GetSales()
	  { //cout << sales << endl;
		return sales;
	  }

	  void PrintSalesPerson()
	  {
		 PrintEmployee();
		 cout << "Sales Data " << sales << endl;

	  }

	 double AnnualIncome() const
	 {	
	    double ain = Employee::AnnualIncome();
        ain = ain + 0.25 * sales;
		return ain;
	 }
};


int Employee::count = 0;
//Global Function
double Tax(const Employee* e) 
{
	double income = e->AnnualIncome();
	double tax = (income > 50000) ? (income - 50000) * 0.1 : 0;
    return tax;
}

double GetTotalSales(Employee* e[], int size)
{
   double tsales = 0;
   for (int i = 0; i < 5; i++)
   {   // Static cast does not check before casting
       // Directly does the casting, is not safe
       // SalesPerson* s =  static_cast<SalesPerson*>(e[i]);
          
        SalesPerson* s =  dynamic_cast<SalesPerson*>(e[i]);
        if (s)
			tsales = tsales + s->GetSales();
		//cout << "count : " << i <<"/ " << tsales << endl;
   }

   return tsales;


}

int main()
{
  Employee e[5];
  Employee* emp[5];
  emp[0] = new Employee(20000, 5000, 23);
  emp[1] = new SalesPerson(25000, 5000, 24, 50000);
  emp[2] = new Employee(23000, 4000, 25);
  emp[3] = new SalesPerson(30000, 4000, 25, 75000);
  emp[4] = new Employee(40000, 15000, 26);
  double totalsales = GetTotalSales(emp, 5);
  cout << totalsales<< endl;
  return 0;

}




